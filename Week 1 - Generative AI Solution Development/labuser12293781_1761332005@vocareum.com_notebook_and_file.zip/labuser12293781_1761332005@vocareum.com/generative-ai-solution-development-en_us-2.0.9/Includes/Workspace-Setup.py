# Databricks notebook source
# MAGIC %md
# MAGIC # Workspace Setup
# MAGIC
# MAGIC This notebook includes code for setting up the workspace.