# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Generative AI Application Development
# MAGIC
# MAGIC This course provides participants with information and practical experience in building advanced LLM (Large Language Model) applications using multi-stage reasoning LLM chains and agents. In the initial section, participants will learn how to decompose a problem into its components and select the most suitable model for each step to enhance business use cases. Following this, participants will construct a multi-stage reasoning chain utilizing LangChain and HuggingFace transformers. Finally, participants will be introduced to agents and will design an autonomous agent using generative models on Databricks.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Prerequisites
# MAGIC The content was developed for participants with these skills/knowledge/abilities:
# MAGIC - Familiarity with natural language processing concepts
# MAGIC - Familiarity with prompt engineering/prompt engineering best practices 
# MAGIC - Familiarity with the Databricks Data Intelligence Platform
# MAGIC - Familiarity with RAG  (preparing data, building a RAG architecture, concepts like embedding, vectors, vector databases, etc.)
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Course Agenda  
# MAGIC The following modules are part of the **Generative AI Application Development** course by **Databricks Academy**.
# MAGIC
# MAGIC | # | Module Name | Lesson Name |
# MAGIC |---|-------------|-------------|
# MAGIC | 1 | [Foundations of Compound AI Systems]($./01 - Foundations of Compound AI Systems) | • *Lecture:* Defining Compound AI Systems <br> • *Lecture:* Designing Compound AI Systems <br> • [Demo: Deconstruct and Plan a Use Case]($./01 - Foundations of Compound AI Systems/1.1 - Deconstruct and Plan a Use Case) <br> • [Lab: Planning an AI System for Product Quality Complaints]($./01 - Foundations of Compound AI Systems/1.LAB - Planning an AI System for Product Quality Complaints) |
# MAGIC | 2 | [Building Multi-stage Reasoning Chains]($./02 - Building Multi-stage Reasoning chains) | • *Lecture:* Introduction to Multi-stage Reasoning Chains <br> • [Demo: Building Multi-stage Reasoning Chain in Databricks]($./02 - Building Multi-stage Reasoning chains/2.1 - Building Multi-stage Reasoning Chain in Databricks) <br> • [Lab: Building Multi-stage AI System]($./02 - Building Multi-stage Reasoning chains/2.LAB - Building Multi-stage AI System) |
# MAGIC | 3 | [Agents and Cognitive Architectures]($./03 - Agents and Cognitive Architectures) | • *Lecture:* Introduction to Agents <br> • [Demo: Agent Design in Databricks]($./03 - Agents and Cognitive Architectures/3.1 - Agent Design in Databricks) <br> • [Lab: Create a ReAct Agent]($./03 - Agents and Cognitive Architectures/3.LAB - Create a ReAct Agent) |
# MAGIC  
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Requirements
# MAGIC
# MAGIC Please review the following requirements before starting the lesson:
# MAGIC
# MAGIC * Use Databricks Runtime version:**`17.3.x-cpu-ml-scala2.13`** for running all demo and lab notebooks.

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2025 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>