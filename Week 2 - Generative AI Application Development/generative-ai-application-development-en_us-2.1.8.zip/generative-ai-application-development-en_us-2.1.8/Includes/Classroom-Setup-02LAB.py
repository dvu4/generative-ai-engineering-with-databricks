# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

DA = DBAcademyHelper()
DA.init()

# COMMAND ----------

def create_docs_table(vs_source_table_fullname):
    """
    Load the documentation dataset, process it into a single text field, and save it as a Delta table for vector search.
    """
    # Validate the source table exists
    DA.validate_table("dbacademy_docs.v01.docs")

    # Load and transform the dataset
    dataset = spark.sql(f"""
        SELECT 
            id AS id, 
            CONCAT('## URL: ', url, '\n\n## Content: ', content) AS document 
        FROM dbacademy_docs.v01.docs
    """)

    # Save the transformed dataset to the specified location
    dataset.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(vs_source_table_fullname)

    # Enable Change Data Feed (CDF) for Delta table
    spark.sql(f"""
        ALTER TABLE {vs_source_table_fullname} 
        SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
    """)