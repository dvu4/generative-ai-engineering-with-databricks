
import mlflow
from mlflow.models import set_model
from mlflow.pyfunc import PythonModel

import pandas as pd
import numpy as np

from databricks_langchain import ChatDatabricks
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent

class DataQioModel(PythonModel):
    def load_context(self, context):
        # Load the dataset artifact and initialize LLM once per process
        self.df = pd.read_parquet(context.artifacts["spotify_parquet"])
        self.llm = ChatDatabricks(endpoint="databricks-meta-llama-3-3-70b-instruct", max_tokens=3000)
        self.prefix = (
            " Input should be sanitized by removing any leading or trailing backticks. "
            'If the input starts with "python", remove that word as well. Use the dataset provided. '
            "The output must start with a new line. Make sure the response is valid Python code and <= 5000 tokens."
        )

    def _make_agent(self):
        return create_pandas_dataframe_agent(
            self.llm,
            self.df,
            verbose=False,
            max_iterations=8,
            prefix=self.prefix,
            allow_dangerous_code=True,
            agent_executor_kwargs={"handle_parsing_errors": True},
        )

    def _run_query(self, q: str) -> str:
        agent = self._make_agent()
        result = agent.invoke(q)
        # LangChain agents commonly return {'input': ..., 'output': ...}
        if isinstance(result, dict) and "output" in result:
            return str(result["output"])
        return str(result)

    def _coerce_to_queries(self, model_input):
        # Accept common MLflow input shapes
        if isinstance(model_input, str):
            return [model_input]
        if isinstance(model_input, pd.Series):
            return [str(x) for x in model_input.tolist()]
        if isinstance(model_input, (list, tuple, np.ndarray)):
            return [str(x) for x in list(model_input)]
        if isinstance(model_input, pd.DataFrame):
            if "inputs" in model_input.columns:
                return [str(x) for x in model_input["inputs"].tolist()]
            if model_input.shape[1] == 1:
                return [str(x) for x in model_input.iloc[:, 0].tolist()]
            # last resort: join columns row-wise
            return [" ".join(map(str, row)) for _, row in model_input.astype(str).iterrows()]
        return [str(model_input)]

    def predict(self, context, model_input, params=None):
        queries = self._coerce_to_queries(model_input)
        return [self._run_query(q) for q in queries]

set_model(DataQioModel())
